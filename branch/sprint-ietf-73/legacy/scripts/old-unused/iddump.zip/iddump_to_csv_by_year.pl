#!/usr/bin/perl
use lib '/a/www/ietf-datatracker/release';
use GEN_UTIL;
use GEN_DBUTIL_NEW;
use IETF;

die "USAGE: iddump_to_csv_by_year.pl YYYY\n" unless (defined($ARGV[0]));
$target_year=$ARGV[0];
die "USAGE: iddump_to_csv_by_year.pl YYYY\n" unless ($target_year =~ /\d\d\d\d/);
init_database("ietf");
$dbh=get_dbh();
$DIR_PATH="/home/master-site/htdocs/IESG/internal/IDDUMP/$target_year";
open ID_MASTER,">$DIR_PATH/id-master-$target_year.csv";
open ID_REF,">$DIR_PATH/id-status-$target_year.csv";
open AC_REF,">$DIR_PATH/group-acronym-$target_year.csv";
open TR_COMMENT,">$DIR_PATH/comments-$target_year.csv";
open TR_MSTATE,">$DIR_PATH/tracker-main-state-$target_year.csv";
open TR_SSTATE,">$DIR_PATH/tracker-sub-state-$target_year.csv";
open ID_AUTH,">$DIR_PATH/id-authors-$target_year.csv";
open PEOPLE,">$DIR_PATH/people-$target_year.csv";
open TR,">$DIR_PATH/id-tracker-$target_year.csv";
print ID_MASTER qq{I-D tag,I-D name,filename,intended status ID,revision,revision date,working group acronym ID ,page count,start date,abstract,last modified date
};
print TR_COMMENT qq{I-D tag,revision,comment date,comment time,commented by,comment
};
print ID_AUTH qq{I-D tag, Person tag
};
print TR qq{I-D tag,shepherding ad tag,current state ID,current sub state ID,previous state ID,previous sub state ID,on next telechat,submited by RFC editor,note,last modified date
};
print ID_REF qq{intended status ID,intended status value
};
print AC_REF qq{working group acronym ID,acronym
};
print TR_MSTATE qq{state ID,state name
};
print TR_SSTATE qq{sub state ID,sub state name
};
print PEOPLE qq{Person tag, first name, last name
};
my @List_ac=db_select_multiple($dbh,"select acronym_id,acronym from acronym where acronym_id > 99");
for my $array_ref (@List_ac) {
  my ($acronym_id,$acronym) = @$array_ref;
  print AC_REF qq{$acronym_id,$acronym
};
}
my @List_int=db_select_multiple($dbh,"select intended_status_id,status_value from id_intended_status");
for my $array_ref (@List_int) {
  my ($id,$val) = @$array_ref;
  print ID_REF qq{$id,$val
};
}
my @List_state=db_select_multiple($dbh,"select document_state_id,document_state_val from ref_doc_states_new");
for my $array_ref (@List_state) {
  my ($id,$val) = @$array_ref;
  print TR_MSTATE qq{$id,$val
}; 

}
my @List_sub=db_select_multiple($dbh,"select sub_state_id,sub_state_val from sub_state");
for my $array_ref (@List_sub) {
  my ($id,$val) = @$array_ref;
  print TR_SSTATE qq{$id,$val
}; 

}
my $people_tag_list="";
my @List_auth = db_select_multiple($dbh,"select a.id_document_tag,person_or_org_tag from id_authors a, internet_drafts b where a.id_document_tag=b.id_document_tag and  rfc_number in (select rfc_number from rfcs where year(rfc_published_date)=$target_year)");
for my $array_ref2 (@List_auth) {
  my ($id_document_tag,$person_or_org_tag) = @$array_ref2;
  print ID_AUTH qq{$id_document_tag,$person_or_org_tag
};
  $people_tag_list .= "$person_or_org_tag,";
}
chop($people_tag_list);
my @List_people=db_select_multiple($dbh,"select person_or_org_tag,first_name,last_name from person_or_org_info where person_or_org_tag in ($people_tag_list)");
for my $array_ref (@List_people) {
  my ($person_or_org_tag,$first_name,$last_name)=@$array_ref;
  print PEOPLE qq{$person_or_org_tag,$first_name,$last_name
};
}

@List = db_select_multiple($dbh,"select id_document_tag,id_document_name,group_acronym_id,filename,revision,revision_date,txt_page_count,start_date,abstract,intended_status_id,last_modified_date from internet_drafts where rfc_number in (select rfc_number from rfcs where year(rfc_published_date)=$target_year)");
for my $array_ref (@List) {
  my ($id_document_tag,$id_document_name,$group_acronym_id,$filename,$revision,$revision_date,$txt_page_count,$start_date,$abstract,$intended_status_id,$last_modified_date) = @$array_ref;
  $abstract =~ s/"/""/g;
  $id_document_name =~ s/"/""/g;
  print ID_MASTER qq{$id_document_tag,"$id_document_name",$filename,$intended_status_id,$revision,$revision_date,$group_acronym_id,$txt_page_count,$start_date,"$abstract",$last_modified_date
};
}
my @List_tr=db_select_multiple($dbh,"select a.id_document_tag,person_or_org_tag,cur_state,cur_sub_state_id,prev_state,prev_sub_state_id,agenda,via_rfc_editor,note,event_date from id_internal a, internet_drafts b, iesg_login  where a.id_document_tag=b.id_document_tag and rfc_number in (select rfc_number from rfcs where year(rfc_published_date)=$target_year) and rfc_flag=0 and job_owner=id");
for my $array_ref (@List_tr) {
    my ($id_document_tag,$ad_id,$cur_state,$cur_sub_state_id,$prev_state,$prev_sub_state_id,$agenda,$via_rfc_editor,$note,$event_date) = @$array_ref; 
    $via_rfc_editor = ($via_rfc_editor)?"Yes":"No";
    $agenda=($agenda)?"Yes":"No";
    $note =~ s/"/""/g if my_defined($note);
    print TR qq{$id_document_tag,$ad_id,$cur_state,$cur_sub_state_id,$prev_state,$prev_sub_state_id,$agenda,$via_rfc_editor,"$note",$event_date
};
    my @List_comment=db_select_multiple($dbh,"select comment_date,comment_time,version,comment_text, last_name from document_comments a, iesg_login b where a.created_by=b.id and document_id=$id_document_tag");
    for my $array_ref3 (@List_comment) {
      my ($comment_date,$comment_time,$version,$comment_text,$last_name) = @$array_ref3;
      $comment_text =~ s/<b>//g;
      $comment_text =~ s/<\/b>//g;
      $comment_text =~ s/<br>/\n/g;
      $comment_text = reduce_text_plain($comment_text,4);
      $comment_text =~ s/"/""/g if my_defined($comment_text);
      print TR_COMMENT qq{$id_document_tag,$version,$comment_date,$comment_time,$last_name,"$comment_text"
};
    }
}
close ID_MASTER;
close TR_COMMENT;
close ID_AUTH;
close TR;
close ID_REF;
close AC_REF;
close TR_MSTATE;
close TR_SSTATE;
close PEOPLE;
$dbh->disconnect();
exit;
